﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO.NETDemo
{
    class DBHelper
    {

        public static SqlConnection GetConnection()
        {
            string conn = ConfigurationManager.ConnectionStrings["dbconn"]
                .ConnectionString;

            return new SqlConnection(conn);

        }

    }
}
