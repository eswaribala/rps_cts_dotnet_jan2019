﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO.NETDemo
{
    //CRUD operation 

    //Retrieval 

   
    class SqlAdapterDemo
    {
        public static DataTable GetProducts()
        {
            SqlConnection conn = DBHelper.GetConnection();
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            string query = "Select * from Product";
            //disconnected architecture
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, conn);
            sqlDataAdapter.Fill(ds);
            dt = ds.Tables[0];
            return dt;

        }

     //insert query

           static void AddProduct(DataTable dt)
           {
            SqlConnection conn = DBHelper.GetConnection();
            DataSet ds = new DataSet();
            string query = "Select * from Product";
            //disconnected architecture
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, conn);
            //command builder generates internally query when we update, it
            //may be insert command, delete command or update command
            SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
            sqlDataAdapter.Fill(ds);
            sqlDataAdapter.Update(dt);
           }




        static void Main()
        {
           

            //insert operation
            DataTable dt = new DataTable();
            dt.Columns.Add("ProductId", typeof(Int32));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("DOP", typeof(DateTime));
            dt.Columns.Add("Amount", typeof(Int32));
            dt.Rows.Add(43890, "Water Bottle", new DateTime(2019, 1, 26), 250);
            AddProduct(dt);
            Console.WriteLine("Record Added.....");
            DataTable dt1 = GetProducts();

            foreach(DataRow row in dt1.Rows)
                Console.WriteLine(row[0]+"\t"+row[1]+"\t"+row[2]);
            Console.Read();
        }
    }
}
