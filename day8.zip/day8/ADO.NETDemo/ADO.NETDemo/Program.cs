﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO.NETDemo
{
    class Program
    {
        static void ExceptionDemo()
        {
            // create connection object
            SqlConnection conn = null;
            //query
            string query = "select * from product";
            SqlDataReader sqlDataReader;
            SqlCommand sqlCommand;
            try
            {
                conn = DBHelper.GetConnection();
                //open the connection
                conn.Open();
                //command object to invoke the query
                sqlCommand = new SqlCommand(query, conn);
                //execute the query
                sqlDataReader = sqlCommand.ExecuteReader();
                //read the results
                while (sqlDataReader.Read())
                {
                    Console.Write(sqlDataReader.GetInt32(0) + "\t");
                    Console.Write(sqlDataReader.GetString(1) + "\t");
                    Console.Write(sqlDataReader.GetDateTime(2) + "\t");
                    Console.Write(sqlDataReader.GetInt32(3) + "\n");
                }
            }
            catch (SqlException exception)
            {
                Console.WriteLine(exception.Message);
            }
            finally
            {
                conn.Close();
            }
        }


        static void IDisposableDemo()
        {
            // create connection object
            SqlConnection conn = null;
            //query
            string query = "select * from product";
            SqlDataReader sqlDataReader;
            SqlCommand sqlCommand;
            //invokes IDisposable interface connection will be 
            //disposed at the end
            using (conn = DBHelper.GetConnection())
            {

                try
                {//open the connection
                    conn.Open();
                    //command object to invoke the query
                    sqlCommand = new SqlCommand(query, conn);
                    //execute the query
                    sqlDataReader = sqlCommand.ExecuteReader();
                    //read the results
                    while (sqlDataReader.Read())
                    {
                        Console.Write(sqlDataReader.GetInt32(0) + "\t");
                        Console.Write(sqlDataReader.GetString(1) + "\t");
                        Console.Write(sqlDataReader.GetDateTime(2) + "\t");
                        Console.Write(sqlDataReader.GetInt32(3) + "\n");
                    }
                }
                catch(SqlException ex)
                {

                }
            }
            
        }

        static void GetProductById(int id)
        {
            SqlConnection conn = null;
            //query
            string query = "select * from product where ProductId=@Id";
            SqlDataReader sqlDataReader;
            SqlCommand sqlCommand;
            try
            {
                conn = DBHelper.GetConnection();
                //open the connection
                conn.Open();
                //command object to invoke the query
                sqlCommand = new SqlCommand(query, conn);
                sqlCommand.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                //execute the query
                sqlDataReader = sqlCommand.ExecuteReader();
                //read the results
                sqlDataReader.Read();
                Console.Write(sqlDataReader.GetInt32(0) + "\t");
                Console.Write(sqlDataReader.GetString(1) + "\t");
                Console.Write(sqlDataReader.GetDateTime(2) + "\t");
                Console.Write(sqlDataReader.GetInt32(3) + "\n");
                
            }
            catch (SqlException exception)
            {
                Console.WriteLine(exception.Message);
            }
            catch (InvalidOperationException exception)
            {
                Console.WriteLine(exception.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        static void Main(string[] args)
        {

            ExceptionDemo();
            //IDisposableDemo();
            Console.WriteLine("Enter the Product Id");
            int id = Convert.ToInt32(Console.ReadLine());
            GetProductById(id);
            Console.Read();

        }
    }
}
