﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO.NETDemo
{
    class StoredProcedureDemo
    {
        static void Main()
        {
            SqlConnection conn = DBHelper.GetConnection();
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            string query = "Select * from Product";
            //disconnected architecture
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, conn);
            sqlDataAdapter.Fill(ds);          
            Console.WriteLine("Enter Product Id");
            int id = Convert.ToInt32(Console.ReadLine());
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.Add(new SqlParameter("@Id", id));
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            cmd.CommandText = "DeleteProductById";
            sqlDataAdapter = new SqlDataAdapter(cmd);
            sqlDataAdapter.Fill(ds);           
            Console.WriteLine("Record Deleted");
            Console.Read();
        }
    }
}
