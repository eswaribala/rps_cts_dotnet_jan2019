﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace PaymentGateway
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "BankGateway" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select BankGateway.svc or BankGateway.svc.cs at the Solution Explorer and start debugging.
    public class BankGateway : IBankGateway
    {
        public MessageResponse GetTransaction(MessageRequest request)
        {
            int id = request.AuthenticationKey;
            SqlConnection conn = DbHelper.GetConnection();
            DataSet ds = new DataSet();
            SqlCommand sqlCommand = new SqlCommand();
            sqlCommand.Parameters.Add(new SqlParameter("@Id", id));
            sqlCommand.Parameters.Add("@result", SqlDbType.Int).Direction =
               ParameterDirection.Output;
            sqlCommand.Connection = conn;
            sqlCommand.CommandType = CommandType.StoredProcedure;
            sqlCommand.CommandText = "VerifyKey";
           SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(ds);
            int count =Convert.ToInt32(sqlCommand.Parameters["@result"].Value);

            MessageResponse response = null; 
            if (count>0)
            {
                response = new MessageResponse();
                response.TransactionData = new Transaction
                {
                    TransactionId = 3756,
                    DOT = new DateTime(2019, 2, 8),
                    Amount = 5000
                };
            }

            return response;

        }
    }
}
