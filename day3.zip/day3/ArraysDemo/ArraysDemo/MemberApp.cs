﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysDemo
{
    class MemberApp
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the size");
            int size = Convert.ToInt16(Console.ReadLine());
            Member[] members = new Member[size];
            Member member = null;

            //loop
            for (int i = 0; i < members.Length; i++)
            {
                member = new Member();
                member.MemberId = new Random().Next(100000);
                Console.WriteLine("Enter Name...");
                member.Name = Console.ReadLine();
                Console.WriteLine("Enter DOJ...");
                member.DOJ = Convert.ToDateTime(Console.ReadLine());
                members[i] = member;

            }

            Console.WriteLine("Before Sorting....");
            foreach(Member mem in members)
            {
                Console.WriteLine("Id={0}",mem.MemberId);
                Console.WriteLine("Name={0}",mem.Name);
                Console.WriteLine("DOJ={0}",mem.DOJ);
            }

            //sorting
            Array.Sort(members, new MemberSorter());
            Console.WriteLine("After Sorting....");
            foreach (Member mem in members)
            {
                Console.WriteLine("Id={0}", mem.MemberId);
                Console.WriteLine("Name={0}", mem.Name);
                Console.WriteLine("DOJ={0}", mem.DOJ);
            }

            Console.Read();
        }

    }
}
