﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysDemo
{
    class Customer:IComparable 
    {
        public string Name { get; set; }
        public DateTime DOB { get; set; }
        public long PhoneNo { get; set; }

        public int CompareTo(object obj)
        {
            Customer ReceivedObj = (Customer)obj;
            // return this.Name.CompareTo(ReceivedObj.Name);
            return this.DOB.CompareTo(ReceivedObj.DOB);
        }
    }
}
