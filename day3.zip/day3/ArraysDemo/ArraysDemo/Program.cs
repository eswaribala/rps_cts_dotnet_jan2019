﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Array 
            //typeof the array, array name = new type of the array, size
            Console.WriteLine("Enter the size");
            int size = Convert.ToInt16(Console.ReadLine());
            Customer[] CustomerArray = new Customer[size];
            Customer customer = null;
            //loop
            for(int i=0;i< CustomerArray.Length; i++)
            {
                customer = new Customer();
                Console.WriteLine("Enter Customer Name");
                customer.Name = Console.ReadLine();
                Console.WriteLine("Enter DOB");
                customer.DOB = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Phone No");
                customer.PhoneNo =Convert.ToInt64( Console.ReadLine());
                CustomerArray[i] = customer;
                
            }
            //print customer details
            Console.WriteLine("Before Sorting....");
            for (int i = 0; i < CustomerArray.Length; i++)
            {
                Console.WriteLine("Name={0}", CustomerArray[i].Name);
                Console.WriteLine("DOB={0}", CustomerArray[i].DOB.ToLongDateString());
                Console.WriteLine("Phone No={0}", CustomerArray[i].PhoneNo);
            }
            Array.Sort(CustomerArray);
            Console.WriteLine("After Sorting....");
            for(int i=0;i < CustomerArray.Length; i++)
            {
                Console.WriteLine("Name={0}", CustomerArray[i].Name);
                Console.WriteLine("DOB={0}", CustomerArray[i].DOB.ToLongDateString());
                Console.WriteLine("Phone No={0}", CustomerArray[i].PhoneNo);
            }


            Console.Read();


        }
    }
}
