﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysDemo
{
    class MemberSorter : IComparer<Member>
    {
        public int Compare(Member x, Member y)
        {
            return x.Name.CompareTo(y.Name);
        }
    }
}
