﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockTest1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 65;
            char ch =(char) i;
            Console.WriteLine(ch);
            double d = 10.99;
            int number = (int)d;
            Console.WriteLine(number);
            Console.Read();
            
        }
    }
}
