﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace CricketService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ICricket" in both code and config file together.
    [ServiceContract]
    public interface ICricket
    {
        [OperationContract]
        string GetPresidentName();
        [OperationContract]
        string[] GetPlayerList();
    }
}
