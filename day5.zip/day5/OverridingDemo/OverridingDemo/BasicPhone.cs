﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverridingDemo
{
    class BasicPhone:MobilePhone
    {
        private bool KeyPad;


       
        public override void SMS()
        {
            
            Console.WriteLine("Text from Basic Phone...");
        }

        protected override void Call()
        {
            Console.WriteLine("Calling from Basic Phone");
        }

        public void Test()
        {

        }

    }
}
