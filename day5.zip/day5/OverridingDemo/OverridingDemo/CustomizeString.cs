﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverridingDemo
{
    //Can be instantiated but it cannot be inherited
    sealed class CustomizeString
    {
        private string message;

        CustomizeString()
        {
            this.message = "Welcome";
        }

        public void ReadFourCharacters()
        {
            int count = 0;
            foreach(char ch in message.ToCharArray())
            {
                if (count < 4)
                    Console.Write(ch + "\t");
                else
                    break;

            }

        }
    }
}
