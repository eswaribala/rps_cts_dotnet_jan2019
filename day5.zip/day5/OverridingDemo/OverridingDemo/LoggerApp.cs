﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverridingDemo
{
    class LoggerApp
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Enter Error Message");
            string message = Console.ReadLine();
            Console.WriteLine("Enter Error Level");
            int level = Convert.ToInt32(Console.ReadLine());
            LoggerFactory loggerFactory = new LoggerFactory();
            loggerFactory.RaiseLog(message, level);
            Console.Read();

        }
    }
}
