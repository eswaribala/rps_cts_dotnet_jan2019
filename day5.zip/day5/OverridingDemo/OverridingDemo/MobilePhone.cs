﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverridingDemo
{
    //prevent object created for base class use keyword abstract
    abstract class MobilePhone
    {
        protected string IMEINumber;
        protected int SIMCount;
        protected int price;
        protected int InternalMemory;
        protected string Company;
        //abstract
        protected abstract void Call();
        
        public virtual void SMS()
        {
            Console.WriteLine("SMS Feature Available...");

        }

        //non virtual method
        public void Display()
        {
            Console.WriteLine("Display Screen ...");
        }

        //static method

        public static void Tower()   
        {
            Console.WriteLine("Near by Tower ...");

        }


    }
}
