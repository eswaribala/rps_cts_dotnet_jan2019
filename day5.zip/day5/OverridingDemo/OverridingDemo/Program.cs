﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverridingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            BasicPhone basicPhone = new BasicPhone();
            SmartPhone smartPhone = new SmartPhone();

            //upcasting 
            MobilePhone obj = new BasicPhone();
            //Downcasting
            BasicPhone obj1 = obj as BasicPhone;

            //equal
            if (obj.Equals(obj1))
                Console.WriteLine("Same Objects");
            else
                Console.WriteLine("Different Objects");

            BasicPhone obj3 = new BasicPhone();
            BasicPhone obj4 = new BasicPhone();

            if (obj3.Equals(obj4))
                Console.WriteLine("Same Objects");
            else
                Console.WriteLine("Different Objects");



            //is key word

            if (obj1 is BasicPhone)
            {
                Console.WriteLine("Basic Phone Instance...");

            }

            Console.Read();


        }
    }
}
