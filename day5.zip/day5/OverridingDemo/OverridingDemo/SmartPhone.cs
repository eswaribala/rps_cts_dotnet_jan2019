﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverridingDemo
{
    class SmartPhone:MobilePhone
    {
        private bool TouchScreen;
        private bool ScreenCasting;
        private bool Selfie;
        private bool Cam;


        protected override void Call()
        {
            Console.WriteLine("Calling from Smart Phone...");
        }

        public override void SMS()
        {
            Console.WriteLine("Text from Smart Phone...");
        }
    }
}
