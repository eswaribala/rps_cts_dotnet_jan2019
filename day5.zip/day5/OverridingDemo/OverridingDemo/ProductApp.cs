﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverridingDemo
{
    class ProductApp
    {
        
        static void Main(string[] args)
        {
           Product p1 = new Product { Name = "Laptop", Model = "Dell I7 8thGen",
                Remarks = "Good" };
            Product p2 = new Product
            {
                Name = "Laptop",
                Model = "Mac Pro",
                Remarks = "Good"
            };
            Product p3 = new Product
            {
                Name = "Laptop",
                Model = "Lenovo I7",
                Remarks = "Bad Performance"
            };

            if (p1.Equals(p2))
                Console.WriteLine("Equal");
            else
                Console.WriteLine("Not Equal");
            if (p1.Equals(p3))
                Console.WriteLine("Equal");
            else
                Console.WriteLine("Not Equal");
            Console.Read();

        }
    }

    class  Customer{
 string name;
 uint id;
  Customer() {}
 static void Main() {
     Customer c = new Customer();
     Console.Write(c.name.Length);
 }
}

}
