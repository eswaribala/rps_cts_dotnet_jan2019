﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverridingDemo
{
    class Product
    {
        public string Name { get; set; }
        public string Model { get; set; }
        public string Remarks { get; set; }

        public override bool Equals(object obj)
        {
            bool status = false;
            Product prod = obj as Product;
            if (this.Remarks.Equals(prod.Remarks))
                status = true;
            return status;

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
}
