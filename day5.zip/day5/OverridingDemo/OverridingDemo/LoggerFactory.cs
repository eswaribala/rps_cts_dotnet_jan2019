﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OverridingDemo
{
    class LoggerFactory
    {
        //has relationship
       private Logger logger;
       
       public  void RaiseLog(string message, int level)
        {

            switch(level)
            {
                case 1:
                    this.logger = new TicketLogger();
                    break;
                case 2:
                    this.logger = new FileLogger();
                    break;
            }

            this.logger.WriteToLog(message);
        }


    }
}
