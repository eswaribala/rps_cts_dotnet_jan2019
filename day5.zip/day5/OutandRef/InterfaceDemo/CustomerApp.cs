﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    class CustomerApp
    {
        static void Main(string[] args)
        {
            Customer customer1 = new Customer
            {
                FirstName = "Parameswari",
                LastName = "Bala"
            };

            Customer customer2 = customer1.Clone() as Customer;
            Console.WriteLine("FirstName={0}", customer2.FirstName);
              customer2.FirstName = "Vignesh";
            Console.WriteLine("FirstName={0}", customer2.FirstName);
            //equals
            if (customer1.Equals(customer2))
                Console.WriteLine("Equal");
            else
                Console.WriteLine("Not Equal");

            Console.Read();


        }
    }
}
