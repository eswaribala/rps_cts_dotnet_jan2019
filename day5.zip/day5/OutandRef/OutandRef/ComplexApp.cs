﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OutandRef
{
    class ComplexApp
    {

        static void Main(string[] args)
        {
            Complex c1 = new Complex();
            c1.Real = 5;
            c1.Imag = 10;
            Complex c2 = new Complex();
            c2.Real = 20;
            c2.Imag = 34;
            Complex c3 = c1 + c2;
            Console.WriteLine("Real={0},Imginary={1}", c3.Real, c3.Imag);
            Console.Read();
        }
    }
}
