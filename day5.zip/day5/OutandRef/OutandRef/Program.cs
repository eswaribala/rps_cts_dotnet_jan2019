﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OutandRef
{
    class Program
    {
        private string message;
        Program()
        {
            this.message = "Test...";
        }
        static void ChangeValue(ref int i)
        {
            i += 89;
        }
        static void ChangeMessage(ref Program p)
        {
            p.message = "Modified";
        }
        //out must be initalized before returning
        static void ChangeName(string fname,string lname, out string fullname)
        {
            fullname = fname + " " + lname;
        }

        static void Main(string[] args)
        {
            int number=67;
            ChangeValue(ref number);
            Console.WriteLine(number);
            Program program = new Program();
            ChangeMessage(ref program);
            Console.WriteLine(program.message);

            //out variable
            string firstName = "Parameswari";
            string lastName = "Bala";
            string fullName;

            ChangeName(firstName, lastName, out fullName);
            Console.WriteLine(fullName);


            Console.Read();


        }
    }
}
