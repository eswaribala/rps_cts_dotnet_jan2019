﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OutandRef
{
    class Complex
    {
        public int Real { get; set; }
        public int Imag { get; set; }

        public static Complex operator +(Complex obj1,Complex obj2)
        {
            Complex obj3 = new Complex();
            obj3.Real = obj1.Real + obj2.Real;
            obj3.Imag = obj1.Imag + obj2.Imag;
            return obj3;
        }
    }
}
