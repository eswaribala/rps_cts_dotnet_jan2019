﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoInsuranceLib.models
{
    public class Driver
    {
        public string Name { get; }
        public string Address { set; get; }
        public string RelationWithInsured { set; get; }
        public DateTime DOB { get; }
        public Gender GenderType { get; }

        public string DrivingLicenseNo { set; get; }
        public DateTime FromLicense { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string IssuingRTO { get; set; }
        public VehicleType LicenseType { get; set; }
        public DriverType Job { set; get; }

        //constructor
       public Driver(string name,DateTime dob,Gender gender)
        {
            this.Name = name;
            this.DOB = dob;
            this.GenderType = gender;

        }
    }
}
