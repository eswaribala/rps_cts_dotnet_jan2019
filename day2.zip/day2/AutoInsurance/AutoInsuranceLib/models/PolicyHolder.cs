﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoInsuranceLib.models
{
    public class PolicyHolder
    {
        public long PolicyNo { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string NameInsured { get; set; }
        public Gender GenderType { get; set; }
        public string Address { get; set; }
        public DateTime DOB { get; set; }
        public long PhoneNo { get; set; }
        public string Email { get; set; }

    }
}
