﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoInsuranceLib.models
{
    //default visibility at class level internal
    public class Vehicle
    {
       
        //Latest
        //properties behaves like method
        public string RegistrationNo { get; set; }
        public string EngineNo { get; set; }
        public string ChasisNo { get; set; }
        public string Maker { get; set; }
        public string Color { get; set; }
        public DateTime DOP { get; set; }


    }
}

