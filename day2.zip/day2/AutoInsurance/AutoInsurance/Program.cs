﻿
using AutoInsuranceLib.models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
namespace AutoInsurance
{
    class Program
    {
        static void CreateVehicle()
        {
            //Object for Vehicle
            Vehicle vehicleObj = new Vehicle();
            //setter
            Console.WriteLine("Enter Registration No");
            vehicleObj.RegistrationNo = Console.ReadLine();
            Console.WriteLine("Enter Color");
            vehicleObj.Color = Console.ReadLine();
            Console.WriteLine("Enter Engine No");
            vehicleObj.EngineNo = Console.ReadLine();
            Console.WriteLine("Enter Chasis No");
            vehicleObj.ChasisNo = Console.ReadLine();
            Console.WriteLine("Enter Date of purchase");
            string format = "dd MMM yyyy";//Date format to enter date 02 JAN 1980
            string date = Console.ReadLine();        

            DateTime dateTime = DateTime.ParseExact(date, format, 
                CultureInfo.CreateSpecificCulture("en-US"));
            Console.WriteLine(dateTime);

            vehicleObj.DOP = dateTime;
            Console.WriteLine("Enter Maker");
            vehicleObj.Maker = Console.ReadLine();

            //getter
            Console.WriteLine("Registration No={0}", vehicleObj.RegistrationNo);
            Console.WriteLine("Engine No={0}", vehicleObj.EngineNo);
            Console.WriteLine("Chasis No={0}", vehicleObj.ChasisNo);
            Console.WriteLine("Maker={0}", vehicleObj.Maker);
            Console.WriteLine("DOP={0}", vehicleObj.DOP.ToLongDateString());
           
        }


        static void CreatePolicyHolder()
        {
            PolicyHolder policyHolder = new PolicyHolder();
            string phoneNo = "";
            //check the phone no valid or not
            string phoneNoPattern = "^\\d{10}$";
            bool status = false;
            do
            {
                Console.WriteLine("Enter Phone No");
                phoneNo = Console.ReadLine();

                if (Regex.IsMatch(phoneNo, phoneNoPattern))
                {
                    Console.WriteLine("Valid Phone Number");
                    policyHolder.PhoneNo = Convert.ToInt64(phoneNo);
                    status = true;
                }
                else
                    Console.WriteLine("Invalid Phone Number");
            }
            while (!status);

            string emailPattern = @"^\w+[\w-\.]*\@\w+((-\w+)|(\w*))\.[a-z]{2,3}$";

            Console.WriteLine("Enter Email Address");
            string email = Console.ReadLine();
            if (Regex.IsMatch(email, emailPattern))
            {
                Console.WriteLine("Valid Email Address");
            }
            else
                Console.WriteLine("Invalid Email");





        }

        static void CreateDriverInstance()
        {
            //parameterised constructor;
            Driver driverObj = new Driver("Anil", new DateTime(1995, 5, 27), 
                Gender.MALE);
            Console.WriteLine("Name={0}", driverObj.Name);
            Console.WriteLine("DOB={0}", driverObj.DOB.ToLongDateString());
            Console.WriteLine("Gender={0}", driverObj.GenderType);

            
        }


        static void Main(string[] args)
        {
            //CreateVehicle();
            // CreatePolicyHolder();
            CreateDriverInstance();
            Console.Read();


        }
    }
}
