﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuntimePolymorphismDemo
{
    class EmployeeApp
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee(4788, "Anoop", "Chennai");
            Console.WriteLine(employee);
         

            Manager manager = new Manager(54215, "Sunil", "Bangalore",4356,50);
            Console.WriteLine(manager);
            Console.WriteLine(manager.Display());

            //run time polymorphism --- up casting
            Employee empObj = new Manager(53425, "Roopa", "Bangalore", 5356, 25);
            Console.WriteLine(empObj);
            //sub class method not visible to super class
            //Console.WriteLine(empObj.Display());

            //Downcasting -- forcing will lead to run time exception
            //Manager managerObj =(Manager) new Employee(4788, "Anoop", "Chennai");


            Console.Read();

        }

    }
}
