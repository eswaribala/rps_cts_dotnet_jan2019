﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuntimePolymorphismDemo
{
    class Employee
    {
        protected int employeeId;
        protected string name;
        protected string location;

        public Employee(int pid,string pname,string plocation)
        {
            this.employeeId = pid;
            this.name = pname;
            this.location = plocation;
        }
        public override string ToString()
        {
            return "Employee Id=" + this.employeeId + "\nName=" + 
                this.name + "\nLocation=" + this.location;
        }

        

    }
}
