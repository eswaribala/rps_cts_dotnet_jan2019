﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuntimePolymorphismDemo
{
    class Program
    {
        //compile time polymorphism

        void  Message(string text)
        {

            Console.WriteLine(text);
        }
        void Message(float data)
        {
            Console.WriteLine("float Message={0}",data);
        }

        void Message(long data)
        {
            Console.WriteLine("Long Message={0}",data);
        }

        void Message(byte[] data)
        {
            Console.WriteLine(data);
        }
        void Message(bool status, string text)
        {
           if(status)
             Console.WriteLine(text);
        }
        void Message(long count, string text)
        {
            Console.WriteLine("Long...");
            for (int i = 0; i < count; i++)
                Console.WriteLine(text);
        }
        void Message(float count, string text)
        {
            for (int i = 0; i < count; i++)
                Console.WriteLine(text);
        }

        static void Main(string[] args)
        {
            new Program().Message(5,"Welcome");
            Console.Read();
        }
    }
}
