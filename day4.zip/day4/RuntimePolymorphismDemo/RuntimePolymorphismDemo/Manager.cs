﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuntimePolymorphismDemo
{
    class Manager:Employee
    {
        protected int allowance;
        protected int reporteescount;
        public Manager(int pid,string pname,string plocation,int pallowance,int rcount)
            :base(pid,pname,plocation)
        {
            this.allowance = pallowance;
            this.reporteescount = rcount;

        }
        
        public override string ToString()
        {
            Console.WriteLine("Manager Overriden method");
            return base.ToString(); 
        }
        //non overriden method
        public string Display()
        {
            return "\nAllowance=" + this.allowance + "\nReportees=" + this.reporteescount;
        }
    }
}
