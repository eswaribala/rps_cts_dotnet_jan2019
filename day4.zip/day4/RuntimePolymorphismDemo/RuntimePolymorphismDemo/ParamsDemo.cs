﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuntimePolymorphismDemo
{
    class ParamsDemo
    {
        public static void SkillSet(string name,params string[] skills)
        {

            foreach (string skill in skills)
                Console.Write(skill+"\t");

            Console.WriteLine();
        }

        static void Main()
        {
            SkillSet("Param","C++", "Java", "C#", "Angular");
            SkillSet("Bala","C++", "Java");
            SkillSet("Test");
            SkillSet("Ziya","C++", "Java","Python");
            Console.Read();

        }
    }
}
