﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class OrderDemo
    {
        static void Main(string[] args)
        {
            //BaseClass baseClass = new BaseClass();
            DerivedClass derivedClass = new DerivedClass();
            Console.Read();
        }
    }
}
