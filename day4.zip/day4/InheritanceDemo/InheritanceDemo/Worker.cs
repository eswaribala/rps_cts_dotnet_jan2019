﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Worker
    {
        public int Id { get; }
        public string FirstName { get; }
        public string LastName { get; }
        public DateTime DOJ { get; }
        
         static Worker()
        {
            Console.WriteLine("Calling static contructor....");
        }
        
        //parameterised constructor

        public Worker(int id,string firstName,string lastName,DateTime doj)
        {
            Console.WriteLine("Calling Worker Constructor.....");
            this.Id = id;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.DOJ = doj;
        }

        ~Worker()
        {
            Console.WriteLine("Calling Worker Destructor.....");
        }

    }
}
