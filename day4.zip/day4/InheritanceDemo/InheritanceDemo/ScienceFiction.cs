﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class ScienceFiction:Movie
    {
        // fields
        private bool animation;

        public ScienceFiction(int pid, string pname,string pdirector,string phero)
        {
            this.movieId = pid;
            this.name = pname;
            this.director = pdirector;
            this.hero = phero;
            this.heroine = "Emy Jackson";
            this.animation = true;
            this.silverjublee = true;
        }

        //methods
        public void Display()
        {
            Console.WriteLine("Movie Id={0}", this.movieId);
            Console.WriteLine("Movie Name={0}", this.name);
            Console.WriteLine("Movie Director={0}", this.director);
            Console.WriteLine("Movie Hero={0}", this.hero);
            Console.WriteLine("Animation={0}", this.animation);
        }

    }
}
