﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class ContractWorker:Worker
    {
        public int PerDayWage { get; set; }

        public ContractWorker(int id,string firstName,string lastName,DateTime doj)
            :base(id,firstName,lastName,doj)
        {
            Console.WriteLine("Calling Contract worker constructor...");
        }
    }
}
