﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Movie
    {
        //fields
        //It will be visible in external project derived class
        protected int movieId;
        protected string name;
        protected string director;
        protected string hero;
        //default visibility private
        DateTime dor;
        //it is visible within the project/namespace/assembly
        internal string heroine;
        //It will be to all the classes dervied or not within the project
        protected internal bool silverjublee;

        Movie()
        {
            this.movieId = 0;
        }
    }
}
