﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class WorkerApp
    {
        static void Main(string[] args)
        {
            //FullTime Worker object

            FullTimeWorker FTWorker = new FullTimeWorker(35165,"Anoop",
                "Kumar",new DateTime(2002,12,2));
            FTWorker.EL = 12;
            FTWorker.DA = 5;
            FTWorker.PF = 10;
            Console.WriteLine("Id={0}", FTWorker.Id);
            Console.WriteLine("First Name={0}\n LastName={1}\n DOJ={2}\n", 
                FTWorker.FirstName, FTWorker.LastName, FTWorker.DOJ.ToLongDateString());
          


            //Contract worker object
            ContractWorker CTWorker = new ContractWorker(27414, "Roopa", "Singh", 
                new DateTime(2010, 2, 2));
            CTWorker.PerDayWage = 800;
            Console.WriteLine("Id={0}", CTWorker.Id);
            Console.WriteLine("First Name={0}", CTWorker.FirstName);
            Console.WriteLine("Last Name={0}", CTWorker.LastName);
            Console.WriteLine("DOJ={0}", CTWorker.DOJ.ToLongDateString());

            Console.Read();
        }
    }
}
