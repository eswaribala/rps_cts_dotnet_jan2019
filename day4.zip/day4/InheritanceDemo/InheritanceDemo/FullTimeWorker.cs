﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class FullTimeWorker:Worker
    {
        public int EL { get; set; }
        public int DA { get; set; }
        public int PF { get; set; }

        static FullTimeWorker()
        {
            Console.WriteLine("Calling Full time static constructor...");
        }
        public FullTimeWorker(int id,string firstName,string lastName,DateTime doj)
            :base(id,firstName,lastName,doj)
        {
            Console.WriteLine("Calling Full time worker constructor...");
        }

        ~FullTimeWorker()
        {
            Console.WriteLine("Calling Full time worker destructor...");
        }
    }
}
