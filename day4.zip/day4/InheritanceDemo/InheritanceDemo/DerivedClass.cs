﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class DerivedClass:BaseClass
    {
        static int derCount = 0;
        static DerivedClass()
        {
            Console.WriteLine("Derived Count={0}", ++derCount);
        }
        public DerivedClass()
        {
            Console.WriteLine("Derived instance Count={0}", ++derCount);
        }
    }
}
