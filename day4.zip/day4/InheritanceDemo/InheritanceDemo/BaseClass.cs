﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class BaseClass
    {
        static int count = 0;
        static BaseClass()
        {
            Console.WriteLine("Count={0}", ++count);
        }

        public BaseClass()
        {
            Console.WriteLine("Instance Count={0}", ++count);
        }
    }
}
