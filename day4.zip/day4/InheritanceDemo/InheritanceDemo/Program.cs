﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //create instance
            Product product = new Product
            {
                ProductId = 1,
                Name = "Laptop",
                DOP = new DateTime(2018, 12, 2)
            };

            Console.WriteLine(product);
            Console.Read();
        }

        
    }
}
