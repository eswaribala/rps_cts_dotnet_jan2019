﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Product
    {
        
        public int ProductId { get; set; }
        public string Name { get; set; }
        public DateTime DOP { get; set; }
        //convert object to string
        public override string ToString()
        {
            return "Product Id=" + this.ProductId 
                + "\n" + "Name=" + this.Name + 
                "\n" + "DOP" + this.DOP.ToLongDateString();
        }
        

    }
}
