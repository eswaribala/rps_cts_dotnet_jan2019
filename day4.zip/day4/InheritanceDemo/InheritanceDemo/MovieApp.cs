﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class MovieApp
    {
        static void Main(string[] args)
        {
            Movie movie1 = new Movie();
            movie1.heroine = "Emy";
            movie1.silverjublee = true; 
            ScienceFiction movie = new ScienceFiction(27456,"Robo 2.0","Shankar","Rajni");
            movie.Display();
            Console.Read();
        }
    }
}
