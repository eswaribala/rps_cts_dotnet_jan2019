﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace XMLDemo
{
    class CustomerApp
    {
        static void Main()
        {
            IList<Customer> customers = new List<Customer>();
            Customer customer = null;
            for (int i=0;i<10;i++)
            {
                customer = new Customer { CustomerId = i,
                    Name = "A" + i,
                    DOB = new DateTime(1980 - i, 12 - i, 31 - i) };
                customers.Add(customer);
            }
            //Idisposable interface
            using (XmlWriter xmlWriter = XmlWriter.Create("Customers.xml"))
            {
                xmlWriter.WriteStartDocument();
                xmlWriter.WriteStartElement("Customers");
                foreach(Customer cust in customers)
                {
                    xmlWriter.WriteStartElement("Customer");
                    xmlWriter.WriteElementString("CustomerId", cust.CustomerId.ToString());
                    xmlWriter.WriteElementString("Name", cust.Name);
                    xmlWriter.WriteElementString("DOB", cust.DOB.ToLongDateString());
                    xmlWriter.WriteEndElement();

                }
                xmlWriter.WriteEndElement();
                xmlWriter.WriteEndDocument();
            }

            Console.Read();

        }
    }
}
