﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
namespace XMLDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            XmlTextReader xmlTextReader = new XmlTextReader("Movie.xml");
            while(xmlTextReader.Read())
            {
                switch(xmlTextReader.NodeType)
                {
                    case XmlNodeType.Element:
                        Console.WriteLine(xmlTextReader.Name);
                        Console.WriteLine("Attributes....");
                        if (xmlTextReader.HasAttributes)
                        {
                            for (int i = 0; i < xmlTextReader.AttributeCount; i++)
                            {
                                xmlTextReader.MoveToAttribute(i);
                                Console.WriteLine("Name={0}, Value={1}",
                                    xmlTextReader.Name, xmlTextReader.Value);
                            }
                        }
                        break;
                  
                    case XmlNodeType.Text:
                        Console.WriteLine(xmlTextReader.Value);
                        break;
                    case XmlNodeType.EndElement:
                        Console.WriteLine(xmlTextReader.Name);
                        break;
                    case XmlNodeType.Comment:
                        Console.WriteLine(xmlTextReader.Value);
                        break;
                   

                }
            }
            Console.Read();
        }
    }
}
