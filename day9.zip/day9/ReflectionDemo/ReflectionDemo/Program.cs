﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //reflection
            Console.WriteLine("Enter dll full path");
            string file = Console.ReadLine();
            Console.WriteLine(file);
            Assembly assembly = Assembly.LoadFrom(file);
            Type[] types = assembly.GetTypes();

            Console.WriteLine("Types={0}",types.Length);
            foreach(Type type in types)
            {
                Console.WriteLine(type.FullName);
                Console.WriteLine(type.Namespace);
                MethodInfo[] methods =type.GetMethods();
                Console.WriteLine("Methods={0}",methods.Length);
                foreach(MethodInfo method in methods)
                {
                    Console.WriteLine(method.IsPublic);
                    Console.WriteLine(method.Name);

                }
               ConstructorInfo[] constructorInfos = type.GetConstructors();
                Console.WriteLine("Constructors={0}",constructorInfos.Length);
                FieldInfo[] fieldInfos = type.GetFields();
                Console.WriteLine("Fields={0}",fieldInfos.Length);
                PropertyInfo[] propertyInfos= type.GetProperties();
                Console.WriteLine("Properties={0}",propertyInfos.Length);
            }

            Console.Read();

        }
    }
}
