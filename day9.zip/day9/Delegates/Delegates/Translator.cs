﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    class Translator
    {
        public string EnglishToTamil(string msg)
        {
            string result = "No Match Found";
            Hashtable ht = new Hashtable();
            ht.Add("Hello", "Vanakkam");
            ht.Add("Good Morning", "Kalai Vanakam");
            foreach(DictionaryEntry de in ht)
            {
                if (de.Key.Equals(msg))
                {
                    result = de.Value.ToString();
                    break;
                }
            }
            return result;
        }

        public string EnglishToHindi(string msg)
        {
            string result = "No Match Found";
            Hashtable ht = new Hashtable();
            ht.Add("Hello", "Namasthe");
            ht.Add("Good Morning", "Shubh Prabhat");
            foreach (DictionaryEntry de in ht)
            {
                if (de.Key.Equals(msg))
                {
                    result = de.Value.ToString();
                    break;
                }
            }
            return result;
            
        }

        public string EnglishToTeugu(string msg)
        {
            string result = "No Match Found";
            Hashtable ht = new Hashtable();
            ht.Add("Hello", "Namaskaram");
            ht.Add("Good Morning", "Shubhodayaam");
            foreach (DictionaryEntry de in ht)
            {
                if (de.Key.Equals(msg))
                {
                    result = de.Value.ToString();
                    break;
                }
            }
            return result;
        }




    }
}
