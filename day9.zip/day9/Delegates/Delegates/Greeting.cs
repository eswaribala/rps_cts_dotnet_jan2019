﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    class Greeting
    {
        public void Message(string msg)
        {
            Console.WriteLine("Message={0}",msg);
        }

        public void StoreMessage(string msg)
        {
            StreamWriter sw = new StreamWriter("messages.txt");
            sw.WriteLine(msg);
            sw.Close();

        }

    }
}
