﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{

    class TranslatorApp
    {
        //declared
        public delegate string TranslatorDelegate(string info);
        static void Main()
        {
            Translator translator = new Translator();
            //object
            TranslatorDelegate translatorDelegate = 
                new TranslatorDelegate(translator.EnglishToTamil);
            translatorDelegate +=
                new TranslatorDelegate(translator.EnglishToHindi);
            translatorDelegate +=
               new TranslatorDelegate(translator.EnglishToTeugu);                               
            
            foreach(TranslatorDelegate del in translatorDelegate.GetInvocationList())
            {
                Console.WriteLine(del("Good Morning"));
            }
                 

            Console.Read();
        }

      

    }
}
