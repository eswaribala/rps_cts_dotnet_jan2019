﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    class Program
    {
        //step 1 declare delegate
        public delegate void GreetingDelegate(string data);
        static void Main(string[] args)
        {
            Greeting greeting = new Greeting();
            //step 2 instantiate delegate -- function pointer
            GreetingDelegate gd = new GreetingDelegate(greeting.Message);
            gd += new GreetingDelegate(greeting.StoreMessage);

            //step 3 invoke the delegate
            gd("Welcome to Deleagtes and Events Module....");
            Console.Read();
        }
    }
}
