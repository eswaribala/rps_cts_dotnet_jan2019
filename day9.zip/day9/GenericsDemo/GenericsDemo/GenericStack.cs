﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsDemo
{
    //class level Generic
    class GenericStack<E>
    {
        private Stack<E> stack;
        public GenericStack()
        {
            this.stack = new Stack<E>();
        }

        public void AddElement(E item)
        {
            this.stack.Push(item);
        }

        public void RemoveElement()
        {
          if(this.stack.Count>0)
            Console.WriteLine(this.stack.Pop());

        }

    }
}
