﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsDemo
{
    class GenericStackApp
    {

        static void Main()
        {
            GenericStack<Int32> genericStack = new GenericStack<Int32>();
            genericStack.AddElement(67);
            genericStack.AddElement(68);
            genericStack.AddElement(69);
            genericStack.RemoveElement();

            GenericStack<string> genericStackObj = new GenericStack<string>();
            genericStackObj.AddElement("TCS");
            genericStackObj.AddElement("IBM");
            genericStackObj.AddElement("HCL");
            genericStackObj.RemoveElement();
            Console.Read();
        }
    }
}
