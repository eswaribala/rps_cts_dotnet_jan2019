﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Dynamic Type
            Console.WriteLine("Enter type");

            string typeName = Console.ReadLine();
            Type typeArgument = Type.GetType(typeName);

            Type genericClass = typeof(Member<>);
          
            Type constructedClass = genericClass.MakeGenericType(typeArgument);

            object created = Activator.CreateInstance(constructedClass);


            Console.Read();

        }
    }
}
