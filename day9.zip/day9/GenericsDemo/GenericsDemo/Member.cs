﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsDemo
{
    class Member<T>
    {
     
        public T  PhoneNo{ get; set; }
        public T PANNo{ get; set; }


    }
}
