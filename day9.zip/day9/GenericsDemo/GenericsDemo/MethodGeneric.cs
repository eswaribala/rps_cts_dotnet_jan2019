﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsDemo
{
    class MethodGeneric
    {
        //method level generic
        static void Print<T>(T[] items)
        {
            Console.WriteLine(typeof(T));
            foreach (T t in items)
                Console.WriteLine(t);
            
        }

        static void Main()
        {
            //modify in break
           
            int[] data = { 578, 4876, 69879, 540670 };
            Print<Int32>(data);
            string[] names = { "Vikesh", "Vinod", "Veermani", "Vishal" };
            Print<string>(names);
            Console.Read();

        }

    }
}
