﻿using Business;
using Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter No of Books");
            int size = Convert.ToInt32(Console.ReadLine());
            BookManager bookManager = new BookManager();
            Book book = null;
            Author author = null;
            ArrayList authorList =null;
            int count = 0;
            for(int i=0;i<size;i++)
            {
                book = new Book();
                book.ISBNCode = new Random().Next(100000);
                Console.WriteLine("Enter Book Name");
                book.Name = Console.ReadLine();
                Console.WriteLine("Enter Book DOP");
                book.DOP = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Book COST");
                book.Cost= Convert.ToDouble(Console.ReadLine());
                //author details
                Console.WriteLine("Enter No of Authors");
                count = Convert.ToInt32(Console.ReadLine());
                author = null;
                authorList = new ArrayList();
                for (int j=0;j<count;j++)
                {
                    author = new Author();
                    Console.WriteLine("Enter Author First Name");
                    author.FirstName = Console.ReadLine();
                    Console.WriteLine("Enter Author Last Name");
                    author.LastName = Console.ReadLine();
                    Console.WriteLine("Enter Author Country");
                    author.Country= Console.ReadLine();
                    authorList.Add(author);

                }
                book.Authors = authorList;
                book.PublisherObj = new Publisher
                {
                    PubName = "Eastern Wiley",
                    Address = "Delhi",
                    PhoneNo = 478584376
                };

                bookManager.AddBook(book);
            }

            Console.Read();
        }
    }
}
