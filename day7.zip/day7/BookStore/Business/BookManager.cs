﻿using Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    //CRUD operation
    public class BookManager
    {
        private IList books;
        private bool status;
        public BookManager()
        {
            this.books = new ArrayList();
        }

        //add book
        public void AddBook(Book book)
        {
            this.books.Add(book);
        }

        //remove book
        public bool RemoveBook(int code)
        {
            //Book found = null;

            foreach (Book obj in this.books)
            {
                if (obj.ISBNCode == code)
                {
                    //found = obj;
                    this.books.Remove(obj);
                    status = true;
                    break;
                }
            }
            //if (found != null)
            //{
            //    this.books.Remove(found);
            //    status = true;
            //}
            return status;
        }

    }
}
