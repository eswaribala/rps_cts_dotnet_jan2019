﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Publisher
    {
        public string PubName { get; set; }
        public string Address { get; set; }
        public long PhoneNo { get; set; }

    }
}
