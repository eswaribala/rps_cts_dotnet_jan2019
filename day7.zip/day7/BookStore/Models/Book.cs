﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Book
    {
        public int ISBNCode { get; set; }
        public string Name { get; set; }
        public DateTime DOP { get; set; }
        public IList Authors { get; set; }

        public double Cost { get; set; }
        public Publisher PublisherObj { get; set; }
       


    }
}
