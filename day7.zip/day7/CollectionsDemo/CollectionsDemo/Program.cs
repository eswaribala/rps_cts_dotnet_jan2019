﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arrayList = new ArrayList();
            arrayList.Add(4576);
            arrayList.Add("test");
            arrayList.Add(true);
            arrayList.Add(3.45f);
            arrayList.Add(350.89);
            arrayList.Add(327476.7897m);
            arrayList.Add(DateTime.Today);
            Console.WriteLine("No of Elements={0}",arrayList.Count);
            //iteration 
            //method1
            IEnumerator data=arrayList.GetEnumerator();
            while (data.MoveNext())
                Console.WriteLine(data.Current);
            //method 2
            foreach(Object obj in arrayList)
            {
                Console.WriteLine(obj);

            }
            //method 3
            for(int i=0;i<arrayList.Count;i++)
            {
                 Console.WriteLine(arrayList[i]);
            }

            Console.WriteLine(arrayList[4]);
            
            //method 4
            foreach (var elem in arrayList)
            {
                if (elem.GetType().ToString().Equals("System.String"))
                    {
                     Console.WriteLine(elem);
                }

                if(elem is System.String)
                    Console.WriteLine(elem);

                if (elem.GetType()==typeof(string))
                {
                      Console.WriteLine(elem);
                }

            }



            Console.Read();

        }
    }
}
