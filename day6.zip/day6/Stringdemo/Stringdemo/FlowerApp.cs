﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stringdemo
{
    class FlowerApp
    {
        static void Main(string[] args)
        {
            FlowerArray flowerArray = new FlowerArray();
            Flower flower = null; 

            for(int i=0;i<5;i++)
            {
                flower = new Flower { Name = "Jasmine"+i, Color = "white", Fragrance=true};
                flowerArray[i] = flower;

            }

            // retrieve
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Name={0}", flowerArray[i].Name);
                Console.WriteLine("Color={0}", flowerArray[i].Color);
                Console.WriteLine("Name={0}", flowerArray[i].Fragrance);
            }


                Console.Read();
        }

    }
}
