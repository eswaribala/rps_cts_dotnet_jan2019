﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stringdemo
{
    class FlowerArray
    {
        private Flower[] flowers = new Flower[5];
        //indexer-- position of a array like property
        public Flower this[int pos]
        {
            get
            {
                return flowers[pos];
            }

            set
            {
                flowers[pos] = value;
            }
        }
    }
}
