﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stringdemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string message = "Welcome to c# training";
            //length
            Console.WriteLine("Length={0}",message.Length);
            //starts with
            bool status = message.StartsWith("Welcome");
            Console.WriteLine("Status of StartsWith={0}", status);

            //ends with
            status = message.EndsWith("training");
            Console.WriteLine("Status of EndsWith={0}", status);  

            //index of 
            int position = message.IndexOf("z");
            Console.WriteLine("First Occurrence Position={0}", position);

            //Remove
            string newMessage = message.Remove(4);
            Console.WriteLine("New String={0}", newMessage);
            //start position, count
            newMessage = message.Remove(4,3);
            Console.WriteLine("New String={0}", newMessage);

            // replace
            newMessage=message.Replace("c#", "f#");
            Console.WriteLine("New String={0}", newMessage);
            newMessage = message.Replace("training", "Workshop");
            Console.WriteLine("New String={0}", newMessage);

            //immutable

            string data = "CTS,Ramanujam IT Park";
            data=data.Remove(4);
            Console.WriteLine("Data={0}", data);

            data = "CTS Ramanujam IT Park";
            //replace
            data=data.Replace(" ", "->");
            Console.WriteLine("Data={0}", data);

            //split
            data = "CTS Ramanujam IT Park";
            string[] words=data.Split(' ');
            foreach (string word in words)
                Console.WriteLine(word);
            //trim
            data = "MMMMMCTS Ramanujam IT Park     ";
            data = data.TrimStart('M');
            Console.WriteLine("Data={0}", data);

            //compare
            string message1 = "i will be travelling";
            string message2 = "I will be travelling";
            int result = String.Compare(message1, message2,true);
            Console.WriteLine("Result={0}", result);


            string[] names = { "CTS", "HCL", "IBM" };
            foreach(string name in names)
            {
                if (name.Equals("HCL"))
                    Console.WriteLine("found");
            }


            Console.Read();

        }
    }
}
