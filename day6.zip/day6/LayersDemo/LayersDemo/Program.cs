﻿using BusinessLayer;
using ExceptionLayer;
using ModelLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayersDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Array size");
            int size = Convert.ToInt32(Console.ReadLine());
            JPMilesManager jPMilesManager = new JPMilesManager(size);
            Member member = null;
            for(int i=0;i<size;i++)
            {
                member = new Member();
                Console.WriteLine("Enter Name");
                member.Name = Console.ReadLine();
                Console.WriteLine("Enter Flying Hours");
                member.JPMiles = Convert.ToInt32(Console.ReadLine());
                try
                {
                    jPMilesManager.AddMember(member, i);
                }
                catch(JPMilesException exception)
                {
                    Console.WriteLine("You are not Frequent Flyer={0}", exception.Message);
                }
            }

            //Retrieve all Frequent Flyers

            foreach(Member mem in jPMilesManager.GetAll())
            {
                if(mem!=null)
                {
                    Console.WriteLine("Name={0}\n JPMiles={1}", mem.Name, mem.JPMiles);
                }

            }

           

            Console.Read();

        }
    }
}
