﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelLayer
{
    public class Member
    {
        public string Name { get; set; }
        public int JPMiles { get; set; }

        public bool FrequentFlyer { get; set; }
    }
}
