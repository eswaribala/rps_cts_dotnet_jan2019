﻿using ExceptionLayer;
using ModelLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class JPMilesManager
    {
        private Member[] members;


        public JPMilesManager(int size)
        {
            this.members = new Member[size];
        }

        public void AddMember(Member member,int pos)
        {
            if (member.JPMiles > 20000)
            {
                member.FrequentFlyer = true;
                members[pos] = member;

            }
            else
                throw new JPMilesException("JP Miles Value is low");


        }


        public Member[] GetAll()
        {
            return this.members;
        }


    }
}
