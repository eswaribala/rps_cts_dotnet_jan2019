﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionLayer
{
    public class JPMilesException:ApplicationException
    {
        public JPMilesException(string message):base(message)
        {

        }
    }
}
