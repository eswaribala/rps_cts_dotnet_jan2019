﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class Member
    {
        public string Name { get; set; }
        public int JPMiles { get; set; }
        public bool FrequentFlyer { get; set; }
    }
}
