﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class TryandFinallyApp
    {

        static void ProcessData(string value)
        {
            try
            {
                Console.WriteLine("Index position={0}", value.IndexOf('n'));
            }
            finally
            {
                Console.WriteLine("Exiting from Method.....");
            }
        }
        static void Main(string[] args)
        {

            try
            {
                ProcessData(null);
            }
            catch(NullReferenceException exception)
            {
                Console.WriteLine("Exception Message={0}", exception.Message);
            }
            Console.Read();
        }
    }
}
