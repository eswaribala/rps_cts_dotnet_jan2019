﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;


namespace ExceptionHandlingDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            //run time exception
            int number = 50;
            int denominator = 0;
           
            try
            {
                
                Console.WriteLine("Enter Value");
                denominator = Convert.ToInt32(Console.ReadLine()); 
                number = number / denominator;
                Console.WriteLine("Average Value={0}", number);
                Console.WriteLine(args[1]);
            }
           

            catch (ArithmeticException exception)
            {
                Console.WriteLine("Arithmrtic Exception={0}",exception.Message);
                Console.WriteLine("Source={0}", exception.Source);
                string stacktrace =exception.StackTrace;
                Console.WriteLine("Stack Trace={0}",stacktrace);
                Console.WriteLine("Target Site={0}", exception.TargetSite);

            }
            catch(FormatException exception)
            {
                Console.WriteLine("Format Exception={0}", exception.Message);
            }
            catch 
            {

                Console.WriteLine("Generic Exception");
            }
            finally
            {
                Console.WriteLine("Enters finally in all cases....");
            }

            Console.WriteLine("Exception Handled .....");
            Console.ReadLine();

        }
    }
}
