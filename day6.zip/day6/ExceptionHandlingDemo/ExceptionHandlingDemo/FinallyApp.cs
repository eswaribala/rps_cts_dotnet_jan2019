﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class FinallyApp
    {
        static int Main(string[] args)
        {
            try
            {
                int k = Int32.Parse(args[0]);
                if (k == 0) return k;
                else
                {
                    k++;
                    return k;
                }
            }
            catch (FormatException d)
            {
                Console.WriteLine(d.Message);
            }
            catch
            {
                Console.WriteLine("some error ");
            }
            finally
            {
                Console.WriteLine("Bye");
            }
            Console.Read();
            return 0;

            
    }
    }
}
