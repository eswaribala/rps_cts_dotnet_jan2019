﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class MemberApp
    {
        static void CheckFrequentFlyer()
        {
            Member member = new Member();
            Console.WriteLine("Enter Name");
            member.Name = Console.ReadLine();
            Console.WriteLine("Enter No of Hours Flown");
            member.JPMiles = Convert.ToInt32(Console.ReadLine());

            if (member.JPMiles > 20000)
                member.FrequentFlyer = true;
            else
                throw new JPMilesException("Not in JP Mile Range");
        }

        static void Main()
        {
            try
            {
                CheckFrequentFlyer();
            }
            catch(JPMilesException exception)
            {
                Console.WriteLine("Exception={0}", exception.Message);
            }
            Console.Read();

        }
    }
}
