﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class ProductApp
    {

        static void TestString(string str)
        {
            if (str == null)
                throw new ArgumentNullException("Argument Null Exception");
            else if (str == "")
                throw new ArgumentException("Argument Empty");
            else
                Console.WriteLine(str);
        }

        static void Readproduct()
        {
            Product product = new Product();
            Console.WriteLine("Enter Expiry Date");
            product.ExpiryDate = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine(DateTime.Today);
            DateTime NextValidDate = DateTime.Today.AddMonths(6);
            if ((product.ExpiryDate >= DateTime.Today) && (product.ExpiryDate < NextValidDate))
                Console.WriteLine("Expiry Date is Valid");
            else
                throw new ArgumentOutOfRangeException("Expiry Date not in expected Range");
        }

        static void Main(string[] args)
        {
            //byte data = 255;
            int intdata = 2147483647;
            try

            {
                // Readproduct();
                TestString("");

            }
            catch (ArgumentNullException exception)
            {
                Console.WriteLine("Exception={0}", exception.StackTrace);
            }

            catch (ArgumentOutOfRangeException exception)
            {
                Console.WriteLine("Exception={0}", exception.StackTrace);
            }
            catch (ArgumentException exception)
            {
                Console.WriteLine("Exception={0}", exception.StackTrace);
            }

            try
            { 

            //checked exception
            intdata = checked(intdata + 5);
                Console.WriteLine(intdata);
               

            }
            catch (ArgumentException exception)
            {
                Console.WriteLine("Exception={0}", exception.StackTrace);
            }
            catch (OverflowException exception)
            {
                Console.WriteLine("Exception={0}", exception.Message);
            }
            Console.Read();

        }
    }
}
