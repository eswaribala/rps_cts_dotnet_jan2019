﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class InnerExceptionApp
    {
        static void NullCheck(string value)

        {
            int length;
            try
            {

             length=value.Length;
            }
            catch(NullReferenceException exception)
            {
                ArgumentException ex = new ArgumentException("Argument Exception", exception);
                throw ex;
            }
        }

        static void Main(string[] args)
        {

            try
            {
                NullCheck(null);
            }
            catch(Exception exception)
            {
                Console.WriteLine(exception.Message);
                Console.WriteLine(exception.InnerException.Message);
            }
            Console.Read();
        }
    }
}
